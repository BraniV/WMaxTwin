# WMaxTwin Tecator Functional Regression Notebook

This package contains a GitHub-ready Jupyter notebook for Example III of the WMaxTwin paper: Tecator spectroscopy functional regression.

## Contents

- `WMaxTwin_Tecator_Functional_Regression_Notebook.ipynb`: annotated executed Python notebook.
- `tecator_wmaxtwin_study.py`: standalone Python script version.
- `tecator_statlib.txt`: local copy of the Tecator StatLib data file used by the notebook so the example can run without network access.
- `tecator_wmaxtwin_section.tex`: LaTeX section used in the paper.
- `requirements.txt`: minimal Python dependencies.

## Run

```bash
pip install -r requirements.txt
jupyter notebook WMaxTwin_Tecator_Functional_Regression_Notebook.ipynb
```

The default notebook run uses 8 repeated internal splits, matching the table in the paper.
The standalone script can be run with:

```bash
python tecator_wmaxtwin_study.py
```
