"""
WMaxTwin+ versus improved MaxTwin+ for the Marron-Wand claw density.

The simulation compares three balanced half-sample split geometries.

1. Random: no balancing geometry.
2. MaxTwin+: nonwavelet local geometry.  The split balances coarse empirical
   rank blocks and then improves global polynomial/rank-bump balance while
   preserving the rank-block balance.
3. WMaxTwin+: wavelet-enriched geometry.  The split first separates adjacent
   order-statistic pairs and then orients those pairs by minimizing imbalance
   in a feature matrix containing MaxTwin+ features and Haar wavelet atoms.

The density estimator, bandwidth, AMSE loss, sample, and evaluation grid are
identical across the three split geometries.

The default run writes:
  wmaxtwin_plus_amse_table.csv
  wmaxtwin_plus_replicates.csv
  fig_wmaxtwin_plus_split_geometry.png
  fig_wmaxtwin_plus_density_estimates.png
  fig_wmaxtwin_plus_amse_bars.png
  fig_wmaxtwin_plus_amse_differences.png
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import trapezoid
from scipy.stats import norm


# ------------------------------------------------------------
# Claw density
# ------------------------------------------------------------


def claw_pdf(x: np.ndarray) -> np.ndarray:
    """Marron-Wand claw density."""
    x = np.asarray(x)
    y = 0.5 * norm.pdf(x, loc=0.0, scale=1.0)
    for ell in range(5):
        y += 0.1 * norm.pdf(x, loc=ell / 2.0 - 1.0, scale=0.1)
    return y


def sample_claw(n: int, rng: np.random.Generator) -> np.ndarray:
    """Draw n observations from the claw density."""
    comp = rng.choice(6, size=n, p=[0.5] + [0.1] * 5)
    means = np.array([0.0, -1.0, -0.5, 0.0, 0.5, 1.0])
    sds = np.array([1.0, 0.1, 0.1, 0.1, 0.1, 0.1])
    return rng.normal(loc=means[comp], scale=sds[comp])


# ------------------------------------------------------------
# Feature construction
# ------------------------------------------------------------


def standardize_columns(F: np.ndarray) -> np.ndarray:
    """Center columns, remove constants, and scale to empirical standard deviation one."""
    F = np.asarray(F, dtype=float)
    F = F - F.mean(axis=0, keepdims=True)
    sd = F.std(axis=0, ddof=1)
    keep = sd > 1.0e-12
    return F[:, keep] / sd[keep]


def rank_coordinate(x: np.ndarray) -> np.ndarray:
    """Empirical rank coordinate in (0,1)."""
    n = len(x)
    ranks = np.empty(n, dtype=int)
    ranks[np.argsort(x)] = np.arange(1, n + 1)
    return ranks / (n + 1.0)


def maxtwin_plus_features(x: np.ndarray, R: int = 10, M: int | None = None) -> np.ndarray:
    """Nonwavelet MaxTwin+ features: moments, rank bins, smooth rank bumps."""
    if M is None:
        M = R
    z = (x - x.mean()) / (x.std(ddof=1) + 1.0e-12)
    u = rank_coordinate(x)

    cols = [z, z**2, z**3, z**4]

    for r in range(R):
        lo, hi = r / R, (r + 1) / R
        cols.append(((u > lo) & (u <= hi)).astype(float))

    tau = 1.2 / (M + 1)
    for m in range(1, M + 1):
        c = m / (M + 1)
        cols.append(np.exp(-0.5 * ((u - c) / tau) ** 2))

    return standardize_columns(np.column_stack(cols))


def haar_wavelet_features(
    x: np.ndarray,
    J: int = 5,
    J0: int | None = None,
    a: float = -3.0,
    b: float = 3.0,
) -> np.ndarray:
    """Pure-Python Haar detail and finest scaling features on the physical x scale."""
    if J0 is None:
        J0 = max(1, J - 3)

    u = np.clip((x - a) / (b - a), 0.0, 1.0 - 1.0e-12)
    cols = []

    for j in range(J0, J + 1):
        m = 2**j
        bins = np.floor(u * m).astype(int)
        loc = u * m - bins
        scale = 2 ** (j / 2)
        for k in range(m):
            v = np.zeros_like(u)
            idx = bins == k
            v[idx] = np.where(loc[idx] < 0.5, 1.0, -1.0) * scale
            cols.append(v)

    # Finest scaling cells.  These make the split sensitive to local mass.
    m = 2**J
    bins = np.floor(u * m).astype(int)
    scale = 2 ** (J / 2)
    for k in range(m):
        cols.append((bins == k).astype(float) * scale)

    return standardize_columns(np.column_stack(cols))


def wmaxtwin_plus_features(x: np.ndarray, R: int = 10, J: int = 5) -> np.ndarray:
    """Equal-group-weighted MaxTwin+ and Haar wavelet features."""
    Fm = maxtwin_plus_features(x, R=R, M=R)
    Fw = haar_wavelet_features(x, J=J)
    Fm = Fm / np.sqrt(Fm.shape[1])
    Fw = Fw / np.sqrt(Fw.shape[1])
    return np.column_stack([Fm, Fw])


# ------------------------------------------------------------
# Split constructors
# ------------------------------------------------------------


def random_split(n: int, rng: np.random.Generator) -> np.ndarray:
    """Balanced random split encoded by +/-1."""
    y = np.r_[np.ones(n // 2, dtype=int), -np.ones(n - n // 2, dtype=int)]
    rng.shuffle(y)
    return y


def feature_objective(F: np.ndarray, y: np.ndarray) -> float:
    s = F.T @ y
    return float(s @ s) / F.shape[1]


def maxtwin_plus_split(
    x: np.ndarray,
    rng: np.random.Generator,
    R: int = 10,
    n_flips: int = 600,
) -> np.ndarray:
    """
    Improved nonwavelet MaxTwin+ split.

    The split first balances coarse empirical rank blocks.  Then it performs
    improving within-block swaps to reduce the MaxTwin+ feature imbalance while
    preserving the exact rank-block balance.
    """
    n = len(x)
    idx = np.argsort(x)
    blocks = np.array_split(idx, R)
    block_id = np.empty(n, dtype=int)
    y = np.zeros(n, dtype=int)
    leftovers = []

    for bi, bidx in enumerate(blocks):
        block_id[bidx] = bi
        bcopy = bidx.copy()
        rng.shuffle(bcopy)
        m = len(bcopy) // 2
        y[bcopy[:m]] = 1
        y[bcopy[m : 2 * m]] = -1
        if len(bcopy) % 2 == 1:
            leftovers.append(int(bcopy[-1]))

    # Assign odd-block leftovers while preserving the total split size.
    if leftovers:
        rng.shuffle(leftovers)
        n_plus = int((y == 1).sum())
        target_plus = n // 2
        for ii in leftovers:
            if n_plus < target_plus:
                y[ii] = 1
                n_plus += 1
            else:
                y[ii] = -1

    F = maxtwin_plus_features(x, R=R, M=R)
    s = F.T @ y
    cur = float(s @ s) / F.shape[1]

    # Swaps only within the same rank block, so rank-block balance is preserved.
    for _ in range(n_flips):
        bi = int(rng.integers(R))
        inds = np.where(block_id == bi)[0]
        pp = inds[y[inds] == 1]
        mm = inds[y[inds] == -1]
        if len(pp) == 0 or len(mm) == 0:
            continue
        ip = int(rng.choice(pp))
        im = int(rng.choice(mm))
        ds = -2.0 * F[ip] + 2.0 * F[im]
        ns = s + ds
        new = float(ns @ ns) / F.shape[1]
        if new < cur:
            y[ip] = -1
            y[im] = 1
            s = ns
            cur = new

    return y


def orient_adjacent_pairs(
    pairs: np.ndarray,
    F: np.ndarray,
    rng: np.random.Generator,
    restarts: int = 10,
    sweeps: int = 5,
) -> np.ndarray:
    """Choose pair orientations by minimizing feature imbalance."""
    D = F[pairs[:, 0], :] - F[pairs[:, 1], :]
    m = D.shape[0]
    best_sgn = None
    best_obj = np.inf

    for _ in range(restarts):
        sgn = rng.choice([-1, 1], size=m)
        vec = D.T @ sgn
        cur = float(vec @ vec) / F.shape[1]

        for _sweep in range(sweeps):
            improved = False
            for q in rng.permutation(m):
                new_vec = vec - 2.0 * sgn[q] * D[q]
                new_obj = float(new_vec @ new_vec) / F.shape[1]
                if new_obj < cur:
                    vec = new_vec
                    cur = new_obj
                    sgn[q] *= -1
                    improved = True
            if not improved:
                break

        if cur < best_obj:
            best_obj = cur
            best_sgn = sgn.copy()

    return best_sgn


def wmaxtwin_plus_split(
    x: np.ndarray,
    rng: np.random.Generator,
    R: int = 10,
    J: int = 5,
    restarts: int = 10,
) -> np.ndarray:
    """
    Wavelet-enhanced WMaxTwin+ split.

    Adjacent order-statistic pairs enforce very local balance.  Pair
    orientations are then chosen by minimizing imbalance in MaxTwin+ features
    augmented with Haar wavelet atoms.
    """
    n = len(x)
    idx = np.argsort(x)
    pairs = idx.reshape(n // 2, 2)
    F = wmaxtwin_plus_features(x, R=R, J=J)
    sgn = orient_adjacent_pairs(pairs, F, rng, restarts=restarts, sweeps=5)

    y = np.zeros(n, dtype=int)
    for q, (a, b) in enumerate(pairs):
        y[a] = int(sgn[q])
        y[b] = -int(sgn[q])
    return y


# ------------------------------------------------------------
# AMSE calculation
# ------------------------------------------------------------


def kde_eval(x: np.ndarray, grid: np.ndarray, h: float) -> np.ndarray:
    return norm.pdf((grid[:, None] - x[None, :]) / h).mean(axis=1) / h


def split_amse(x: np.ndarray, y: np.ndarray, grid: np.ndarray, true_pdf: np.ndarray, h: float) -> float:
    f_plus = kde_eval(x[y == 1], grid, h)
    f_minus = kde_eval(x[y == -1], grid, h)
    ise_plus = trapezoid((f_plus - true_pdf) ** 2, grid)
    ise_minus = trapezoid((f_minus - true_pdf) ** 2, grid)
    return 0.5 * (ise_plus + ise_minus)


# ------------------------------------------------------------
# Simulation and figures
# ------------------------------------------------------------


def run_simulation(
    reps: int = 150,
    seed: int = 20260619,
    h: float = 0.11,
    output_dir: str | Path = ".",
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    settings = [
        {"n": 60, "J": 5, "R": 8},
        {"n": 80, "J": 5, "R": 10},
        {"n": 80, "J": 6, "R": 10},
        {"n": 120, "J": 5, "R": 12},
    ]

    rng = np.random.default_rng(seed)
    grid = np.linspace(-3.5, 3.5, 701)
    true_pdf = claw_pdf(grid)

    rows = []
    example = {}

    for st in settings:
        n, J, R = st["n"], st["J"], st["R"]
        for rep in range(reps):
            x = sample_claw(n, rng)
            y_random = random_split(n, rng)
            y_max = maxtwin_plus_split(x, rng, R=R, n_flips=700)
            y_wmax = wmaxtwin_plus_split(x, rng, R=R, J=J, restarts=10)

            ar = split_amse(x, y_random, grid, true_pdf, h)
            am = split_amse(x, y_max, grid, true_pdf, h)
            aw = split_amse(x, y_wmax, grid, true_pdf, h)

            rows.append(
                {
                    "n": n,
                    "J": J,
                    "R": R,
                    "rep": rep + 1,
                    "AMSE_Random": ar,
                    "AMSE_MaxTwin_plus": am,
                    "AMSE_WMaxTwin_plus": aw,
                    "diff_Random_minus_MaxTwin_plus": ar - am,
                    "diff_MaxTwin_plus_minus_WMaxTwin_plus": am - aw,
                    "abs_signed_overlap": abs(float(y_max @ y_wmax)) / n,
                }
            )

            if not example and n == 80 and J == 6 and rep == 0:
                example = {
                    "x": x.copy(),
                    "y_random": y_random.copy(),
                    "y_max": y_max.copy(),
                    "y_wmax": y_wmax.copy(),
                    "grid": grid.copy(),
                    "true_pdf": true_pdf.copy(),
                    "h": h,
                }

    reps_df = pd.DataFrame(rows)

    summary_rows = []
    for (n, J, R), gdf in reps_df.groupby(["n", "J", "R"], sort=False):
        mr = gdf["AMSE_Random"].mean()
        mm = gdf["AMSE_MaxTwin_plus"].mean()
        mw = gdf["AMSE_WMaxTwin_plus"].mean()
        summary_rows.append(
            {
                "n": n,
                "J": J,
                "R": R,
                "Random": mr,
                "MaxTwin_plus": mm,
                "WMaxTwin_plus": mw,
                "Gain_WMaxTwin_vs_Random_percent": 100.0 * (mr - mw) / mr,
                "Gain_WMaxTwin_vs_MaxTwin_percent": 100.0 * (mm - mw) / mm,
                "Gain_MaxTwin_vs_Random_percent": 100.0 * (mr - mm) / mr,
                "Median_abs_signed_overlap": gdf["abs_signed_overlap"].median(),
                "Frac_MaxTwin_better_than_Random": (gdf["AMSE_MaxTwin_plus"] < gdf["AMSE_Random"]).mean(),
                "Frac_WMaxTwin_better_than_MaxTwin": (gdf["AMSE_WMaxTwin_plus"] < gdf["AMSE_MaxTwin_plus"]).mean(),
            }
        )
    summary_df = pd.DataFrame(summary_rows)

    reps_df.to_csv(output_dir / "wmaxtwin_plus_replicates.csv", index=False)
    summary_df.to_csv(output_dir / "wmaxtwin_plus_amse_table.csv", index=False)

    make_figures(summary_df, reps_df, example, output_dir)

    return summary_df, reps_df, example


def make_figures(summary_df: pd.DataFrame, reps_df: pd.DataFrame, example: dict, output_dir: Path) -> None:
    x = example["x"]
    h = example["h"]
    grid = example["grid"]
    true_pdf = example["true_pdf"]

    # Figure 1: split geometry
    fig, ax = plt.subplots(figsize=(8.0, 3.8))
    methods = [
        ("Random", example["y_random"], 0),
        ("MaxTwin$^+$", example["y_max"], 1),
        ("WMaxTwin$^+$", example["y_wmax"], 2),
    ]
    for label, y, base in methods:
        yy = base + 0.12 * y
        ax.scatter(x, yy, s=24, alpha=0.8, label=label)
    ax.set_yticks([0, 1, 2])
    ax.set_yticklabels(["Random", "MaxTwin$^+$", "WMaxTwin$^+$"])
    ax.set_xlabel("x")
    ax.set_title("Representative split geometry, n=80, J=6")
    ax.legend(loc="upper right", frameon=False)
    fig.tight_layout()
    fig.savefig(output_dir / "fig_wmaxtwin_plus_split_geometry.png", dpi=200)
    plt.close(fig)

    # Figure 2: density estimates
    fig, ax = plt.subplots(figsize=(8.0, 4.2))
    ax.plot(grid, true_pdf, linewidth=2.0, label="true density")
    for label, y in [("MaxTwin$^+$ A", example["y_max"]), ("MaxTwin$^+$ B", -example["y_max"]),
                     ("WMaxTwin$^+$ A", example["y_wmax"]), ("WMaxTwin$^+$ B", -example["y_wmax"])]:
        ax.plot(grid, kde_eval(x[y == 1], grid, h), linewidth=1.1, alpha=0.9, label=label)
    ax.set_xlabel("x")
    ax.set_ylabel("density")
    ax.set_title("Half-sample KDE estimates, n=80, J=6")
    ax.legend(loc="upper right", frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(output_dir / "fig_wmaxtwin_plus_density_estimates.png", dpi=200)
    plt.close(fig)

    # Figure 3: AMSE bars
    labels = [f"n={int(r.n)}, J={int(r.J)}" for _, r in summary_df.iterrows()]
    xpos = np.arange(len(labels))
    width = 0.25
    fig, ax = plt.subplots(figsize=(8.4, 4.4))
    ax.bar(xpos - width, summary_df["Random"], width, label="Random")
    ax.bar(xpos, summary_df["MaxTwin_plus"], width, label="MaxTwin$^+$")
    ax.bar(xpos + width, summary_df["WMaxTwin_plus"], width, label="WMaxTwin$^+$")
    ax.set_xticks(xpos)
    ax.set_xticklabels(labels)
    ax.set_ylabel("mean AMSE")
    ax.set_title("AMSE comparison across split geometries")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output_dir / "fig_wmaxtwin_plus_amse_bars.png", dpi=200)
    plt.close(fig)

    # Figure 4: AMSE differences, positive favors the more structured method
    fig, ax = plt.subplots(figsize=(8.4, 4.4))
    diff_data = []
    diff_labels = []
    for (n, J), gdf in reps_df.groupby(["n", "J"], sort=False):
        diff_data.append(gdf["diff_Random_minus_MaxTwin_plus"].to_numpy())
        diff_labels.append(f"R-M\nn={n},J={J}")
        diff_data.append(gdf["diff_MaxTwin_plus_minus_WMaxTwin_plus"].to_numpy())
        diff_labels.append(f"M-W\nn={n},J={J}")
    ax.boxplot(diff_data, labels=diff_labels, showfliers=False)
    ax.axhline(0.0, linewidth=1.0)
    ax.set_ylabel("AMSE difference")
    ax.set_title("Positive differences favor MaxTwin$^+$ over Random and WMaxTwin$^+$ over MaxTwin$^+$")
    fig.tight_layout()
    fig.savefig(output_dir / "fig_wmaxtwin_plus_amse_differences.png", dpi=200)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=150)
    parser.add_argument("--seed", type=int, default=20260619)
    parser.add_argument("--h", type=float, default=0.11)
    parser.add_argument("--output-dir", type=str, default=".")
    args = parser.parse_args()

    summary_df, _, _ = run_simulation(
        reps=args.reps,
        seed=args.seed,
        h=args.h,
        output_dir=args.output_dir,
    )
    pd.set_option("display.precision", 5)
    print(summary_df)


if __name__ == "__main__":
    main()
