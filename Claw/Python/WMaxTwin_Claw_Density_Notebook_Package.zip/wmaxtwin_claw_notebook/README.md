# WMaxTwin Claw Density Notebook

This repository-ready notebook reproduces and explains Numerical Experiment I from *Multiscale MaxTwin: Data Splitting as Multiscale Feature Geometry*.

## Files

- `WMaxTwin_Claw_Density_Notebook.ipynb`: annotated, self-contained notebook.
- `WMaxTwin_plus_claw_simulation.py`: original Python script used as the basis for the notebook.
- `requirements.txt`: minimal Python package requirements.
- `outputs/`: generated CSV summaries and figures after running the notebook.

## Run

```bash
pip install -r requirements.txt
jupyter notebook WMaxTwin_Claw_Density_Notebook.ipynb
```

The notebook is set to `REPS = 150`, matching the manuscript run. For a quick test, change it to `REPS = 20`.

## Main message

The experiment compares Random splitting, strengthened nonwavelet MaxTwin+, and WMaxTwin+. The estimator, bandwidth, AMSE loss, sample, and evaluation grid are identical across methods. Only the split geometry changes. WMaxTwin+ improves on MaxTwin+ because Haar scale-location features preserve narrow local density components more effectively than rank-local geometry alone.