# WMaxTwin Claw Density R Notebook

This repository-ready folder contains a self-contained R implementation of the claw-density WMaxTwin example.

## Files

- `WMaxTwin_Claw_Density_R_Notebook.Rmd`: RStudio R Notebook with full annotations, code, equations, and figure generation.
- `WMaxTwin_Claw_Density_R_Notebook.ipynb`: Jupyter notebook using an R kernel (`IRkernel`).
- `wmaxtwin_claw_simulation_R.R`: standalone R script version of the notebook code.
- `WMaxTwin_plus_claw_simulation_python_reference.py`: original Python reference script uploaded for the paper example.

## Requirements

The R implementation uses only base R and the `stats` package. To render the R Markdown notebook, RStudio normally provides `rmarkdown` and `knitr`. To run the `.ipynb` version, install an R Jupyter kernel such as `IRkernel`.

## Running

Open `WMaxTwin_Claw_Density_R_Notebook.Rmd` in RStudio and click **Run All** or **Preview**. The notebook writes CSV files and PNG figures to `r_notebook_outputs/`.

The default setting is `REPS <- 150`, matching the paper-scale Monte Carlo size. For a quick smoke test, use `REPS <- 20` or `REPS <- 50`.

## Reproducibility note

Exact numerical values need not match the Python run bit-for-bit because R and NumPy use different random-number streams. The expected qualitative pattern is that Random has the largest mean AMSE, MaxTwin+ improves on Random, and WMaxTwin+ improves further by adding Haar scale-location features.
