# WMaxTwin Doppler/Nason Cross-Validation in R

This package contains an annotated R translation of Example II from the
WMaxTwin paper: Nason-type wavelet cross-validation for the Doppler signal.

## Files

- `WMaxTwin_Doppler_Nason_CV_R_Notebook.Rmd`  
  RStudio notebook with Markdown explanation and executable R chunks.

- `WMaxTwin_Doppler_Nason_CV_R_Notebook.ipynb`  
  Jupyter notebook version using the R kernel.

- `wmaxtwin_doppler_nason_cv_R.R`  
  Standalone R script.  It implements the Symmlet 4 periodic DWT/IDWT,
  masked wavelet FISTA, Nason even/odd CV, MaxTwin fixed-threshold CV,
  WMaxTwin ramp CV, and plotting.

- `reference_outputs_from_python/`  
  Reference output from the executed Python notebook.  These are included for
  comparison because the present code was prepared in an environment without R.

## Dependencies

Base R only.  The wavelet transform is implemented directly from the Symmlet 4
filter coefficients, so no R wavelet package is required.

## How to run

From a terminal:

```bash
Rscript wmaxtwin_doppler_nason_cv_R.R
```

or open the `.Rmd` file in RStudio and run/knit it.

The default run uses:

- `n = 1024`,
- `SNR = 7`,
- `sigma = 1`,
- Symmlet 4,
- levels `j = 3, ..., 9`,
- `NREP = 18` Monte Carlo replications.

For a quick check, edit the top of the R script and set `NREP <- 2` or
`NREP <- 3`.

## Methodological point

Nason's even/odd split is grid-compatible.  A general MaxTwin/WMaxTwin split is
not.  Therefore the example does not apply an ordinary DWT to the retained
observations.  Instead, the fitting step is a masked penalized wavelet least
squares problem on the original grid.

The improvement is attributed to the full construction: WMaxTwin split geometry,
masked wavelet fitting, and a high-frequency ramp threshold family.
