"""
Example 4. MaxTwin / WMaxTwin Nason-type wavelet cross-validation
for Doppler, SNR=7, sigma=1, n=1024 by default.

Main point:
  Nason's even/odd split is grid-compatible.  MaxTwin and WMaxTwin
  splits are geometry-compatible and generally do not leave a dyadic
  subgrid.  The fitting step is therefore done as a masked wavelet
  penalized least squares problem.

Wavelet:
  Default wavelet is sym4, the 8-tap Symmlet.  The code also includes
  db2, the 4-tap Daubechies D4 wavelet.

Daubechies-Lagarias note:
  The functions phijk_dl() and psijk_dl() port the attached MATLAB
  Daubechies-Lagarias evaluators.  For this experiment the design points
  are still a subset of the dyadic grid, so the masked row-restricted DWT
  operator is much faster and numerically equivalent to using the full
  grid wavelet basis matrix and selecting its training rows.  For truly
  off-grid t_i, build the regression design using phijk_dl() and psijk_dl().

Run examples:
  python example4_maxtwin_dl_doppler.py
  python example4_maxtwin_dl_doppler.py --n 2048 --nrep 20 --snr 7 --sigma 1
  python example4_maxtwin_dl_doppler.py --n 512 --wavelet db2
"""

import argparse
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# Orthogonal filters: PyWavelets convention, periodized analysis.
# ------------------------------------------------------------

FILTERS = {
    "sym4": (
        np.array([
            -0.07576571478927333,
            -0.02963552764599851,
             0.49761866763201545,
             0.8037387518059161,
             0.29785779560527736,
            -0.09921954357684722,
            -0.012603967262037833,
             0.0322231006040427,
        ]),
        np.array([
            -0.0322231006040427,
            -0.012603967262037833,
             0.09921954357684722,
             0.29785779560527736,
            -0.8037387518059161,
             0.49761866763201545,
             0.02963552764599851,
            -0.07576571478927333,
        ]),
    ),
    "db2": (
        np.array([
            -0.12940952255126034,
             0.2241438680420134,
             0.8365163037378079,
             0.48296291314453416,
        ]),
        np.array([
            -0.48296291314453416,
             0.8365163037378079,
            -0.2241438680420134,
            -0.12940952255126034,
        ]),
    ),
}

_IDX_CACHE = {}


def get_idx(n, L):
    key = (n, L)
    if key not in _IDX_CACHE:
        m = n // 2
        _IDX_CACHE[key] = (2 * np.arange(m)[:, None] + np.arange(L)[None, :]) % n
    return _IDX_CACHE[key]


def dwt_step(x, h, g):
    idx = get_idx(len(x), len(h))
    X = x[idx]
    return X @ h, X @ g


def idwt_step(a, d, h, g):
    m = len(a)
    n = 2 * m
    idx = get_idx(n, len(h))
    vals = a[:, None] * h[None, :] + d[:, None] * g[None, :]
    x = np.zeros(n)
    np.add.at(x, idx.ravel(), vals.ravel())
    return x


def wavedec_periodic(x, j0=3, wavelet="sym4"):
    h, g = FILTERS[wavelet]
    n = len(x)
    J = int(np.log2(n))
    if 2**J != n:
        raise ValueError("n must be a power of two")
    if not (1 <= j0 < J):
        raise ValueError("j0 must satisfy 1 <= j0 < J")
    a = x.copy()
    details = {}
    for lev in range(J - 1, j0 - 1, -1):
        a, d = dwt_step(a, h, g)
        details[lev] = d
    return a, [details[j] for j in range(j0, J)]


def waverec_periodic(a, details, j0=3, wavelet="sym4"):
    h, g = FILTERS[wavelet]
    cur = a.copy()
    for d in details:
        cur = idwt_step(cur, d, h, g)
    return cur


def soft(x, lam):
    return np.sign(x) * np.maximum(np.abs(x) - lam, 0.0)


def shrink_full(y, lams, j0=3, wavelet="sym4"):
    a, details = wavedec_periodic(y, j0, wavelet)
    details2 = [soft(d, lams[j0 + r]) for r, d in enumerate(details)]
    return waverec_periodic(a, details2, j0, wavelet)

# ------------------------------------------------------------
# Daubechies-Lagarias evaluators ported from the uploaded MATLAB code.
# These are included for off-grid designs. They are not the fast path.
# ------------------------------------------------------------


def binary_digits_fraction(x, nsteps):
    out = []
    z = float(x)
    for _ in range(nsteps):
        if z <= 0.5:
            out.append(0)
            z = 2.0 * z
        else:
            out.append(1)
            z = 2.0 * z - 1.0
    return out


def te0(filt):
    n = len(filt)
    nn = n - 1
    T = np.zeros((nn, nn))
    for i in range(1, nn + 1):
        for j in range(1, nn + 1):
            ind = 2 * i - j
            if 1 <= ind <= n:
                T[i - 1, j - 1] = np.sqrt(2.0) * filt[ind - 1]
    return T


def te1(filt):
    n = len(filt)
    nn = n - 1
    T = np.zeros((nn, nn))
    for i in range(1, nn + 1):
        for j in range(1, nn + 1):
            ind = 2 * i - j + 1
            if 1 <= ind <= n:
                T[i - 1, j - 1] = np.sqrt(2.0) * filt[ind - 1]
    return T


def phijk_dl(z, j, k, filt, nsteps=20):
    N = len(filt) - 1
    x = (2**j) * z - k
    if x <= 0 or x >= N:
        return 0.0
    integ = int(np.floor(x))
    dec = x - integ
    digits = binary_digits_fraction(dec, nsteps)
    T0, T1 = te0(filt), te1(filt)
    prod = np.eye(N)
    for bit in digits:
        prod = prod @ (T1 if bit == 1 else T0)
    y = (2 ** (j / 2.0)) * prod
    yy = np.mean(y, axis=1)
    return float(yy[integ])


def psijk_dl(z, j, k, filt, nsteps=20):
    N = len(filt) - 1
    daun = (N + 1) / 2.0
    x = (2**j) * z - k
    if x <= daun - N or x >= daun:
        return 0.0
    twox = 2.0 * x
    integ = int(np.floor(twox))
    dec = twox - integ
    digits = binary_digits_fraction(dec, nsteps)
    T0, T1 = te0(filt), te1(filt)
    prod = np.eye(N)
    for bit in digits:
        prod = prod @ (T1 if bit == 1 else T0)
    uu = []
    for i in range(1, N + 1):
        index = i + 1 - integ
        if 0 < index < N + 2:
            fi = ((-1.0) ** (-index)) * filt[index - 1]
        else:
            fi = 0.0
        uu.append(fi)
    uu = np.asarray(uu)
    v = (np.ones((1, N)) / N) @ prod.T
    return float((2 ** (j / 2.0 + 0.5)) * (uu @ v.ravel()))

# ------------------------------------------------------------
# Doppler model, SNR convention, and thresholding utilities.
# ------------------------------------------------------------


def doppler_signal(n, snr=7.0, sigma=1.0):
    t = (np.arange(n) + 0.5) / n
    f = np.sqrt(t * (1.0 - t)) * np.sin(2.0 * np.pi * 1.05 / (t + 0.05))
    f = f - np.mean(f)
    f = f * np.sqrt(snr * sigma**2 / np.var(f))
    return t, f


def mse(a, b):
    return float(np.mean((a - b) ** 2))


def sure_threshold_detail(d, sigma=1.0):
    x = np.sort(np.abs(d))
    n = len(x)
    s2 = sigma**2
    csum = np.cumsum(x * x)
    k = np.arange(1, n + 1)
    risks = n * s2 + csum + (n - k) * x * x - 2.0 * s2 * k
    return float(x[int(np.argmin(risks))])


def level_sure_lams(y, j0=3, wavelet="sym4", sigma=1.0):
    J = int(np.log2(len(y)))
    _, details = wavedec_periodic(y, j0, wavelet)
    return {j: sure_threshold_detail(details[j - j0], sigma) for j in range(j0, J)}


def fixed_lams(lam, j0, J):
    return {j: float(lam) for j in range(j0, J)}


def ramp_lams(slope, j0, J, power=1.5):
    return {
        j: float(slope * ((j - j0) / (J - 1 - j0)) ** power)
        for j in range(j0, J)
    }

# ------------------------------------------------------------
# Masked wavelet lasso by FISTA.
# ------------------------------------------------------------


def fit_masked_wavelet(y, mask, lams, j0=3, wavelet="sym4", n_iter=35):
    # Initialize from zero-filled masked data.
    a, details = wavedec_periodic(y * mask, j0, wavelet)
    za = a.copy()
    zd = [d.copy() for d in details]
    tk = 1.0

    for _ in range(n_iter):
        fz = waverec_periodic(za, zd, j0, wavelet)
        resid = mask * (fz - y)
        ga, gd = wavedec_periodic(resid, j0, wavelet)

        a_new = za - ga
        d_new = []
        for r, dz in enumerate(zd):
            j = j0 + r
            d_new.append(soft(dz - gd[r], lams[j]))

        t_new = (1.0 + np.sqrt(1.0 + 4.0 * tk * tk)) / 2.0
        za = a_new + ((tk - 1.0) / t_new) * (a_new - a)
        zd = [dn + ((tk - 1.0) / t_new) * (dn - do) for dn, do in zip(d_new, details)]
        a, details = a_new, d_new
        tk = t_new

    fit = waverec_periodic(a, details, j0, wavelet)
    return fit

# ------------------------------------------------------------
# MaxTwin and WMaxTwin splits.
# ------------------------------------------------------------


def detail_contributions(y, j0=3, wavelet="sym4"):
    a, details = wavedec_periodic(y, j0, wavelet)
    zero_a = np.zeros_like(a)
    out = {}
    for r, d in enumerate(details):
        tmp = [np.zeros_like(dd) for dd in details]
        tmp[r] = d.copy()
        out[j0 + r] = waverec_periodic(zero_a, tmp, j0, wavelet)
    return out


def max_or_wmax_split(y, j0=3, wavelet="sym4", kind="wmax", seed=0):
    n = len(y)
    t = (np.arange(n) + 0.5) / n
    if kind == "nason":
        return np.arange(0, n, 2), np.arange(1, n, 2)

    if kind == "max":
        # True MaxTwin on one-dimensional location gives adjacent twins.
        pairs = [(i, i + 1) for i in range(0, n, 2)]
        train, val = [], []
        for p, (i, j) in enumerate(pairs):
            if p % 2 == 0:
                train.append(i); val.append(j)
            else:
                train.append(j); val.append(i)
        return np.array(train), np.array(val)

    # WMaxTwin: geometry contains location plus high-frequency local energy.
    cont = detail_contributions(y, j0, wavelet)
    J = int(np.log2(n))
    feats = [(t - np.mean(t)) / np.std(t)]
    for j in range(j0, J):
        if j >= J - 3:
            # For n=1024 this emphasizes j=7,8,9.
            rel = j - (J - 3)
            wt = [1.0, 1.8, 2.6][rel]
        else:
            wt = 0.10 * ((j - j0 + 1) / (J - j0)) ** 2
        q = np.abs(cont[j])
        q = (q - np.mean(q)) / (np.std(q) + 1e-12)
        feats.append(np.sqrt(wt) * q)
    X = np.column_stack(feats)

    activity = np.zeros(n)
    for j in range(max(j0, J - 3), J):
        activity += np.abs(cont[j])
    order = list(np.argsort(-activity))

    remaining = set(range(n))
    pairs = []
    for i in order:
        if i not in remaining:
            continue
        remaining.remove(i)
        if not remaining:
            break
        rem = np.fromiter(remaining, dtype=int)
        dist = np.sum((X[rem] - X[i]) ** 2, axis=1)
        jj = int(rem[int(np.argmin(dist))])
        remaining.remove(jj)
        pairs.append((i, jj))

    # Assign one twin to each side, greedily balancing the feature sums.
    bal = np.zeros(X.shape[1])
    train, val = [], []
    for i, j in pairs:
        diff = X[i] - X[j]
        if np.linalg.norm(bal + diff) <= np.linalg.norm(bal - diff):
            train.append(i); val.append(j); bal += diff
        else:
            train.append(j); val.append(i); bal -= diff
    return np.asarray(train), np.asarray(val)

# ------------------------------------------------------------
# CV selection.
# ------------------------------------------------------------


def cv_select_fixed(y, train, val, j0=3, wavelet="sym4", n_iter=30):
    n = len(y)
    J = int(np.log2(n))
    mask_t = np.zeros(n); mask_t[train] = 1.0
    mask_v = np.zeros(n); mask_v[val] = 1.0
    rows = []
    for lam in np.linspace(0.2, 2.4, 12):
        lams = fixed_lams(lam, j0, J)
        pred_t = fit_masked_wavelet(y, mask_t, lams, j0, wavelet, n_iter)
        pred_v = fit_masked_wavelet(y, mask_v, lams, j0, wavelet, n_iter)
        score = np.mean((pred_t[val] - y[val]) ** 2) + np.mean((pred_v[train] - y[train]) ** 2)
        rows.append((float(score), float(lam)))
    rows = sorted(rows)
    return fixed_lams(rows[0][1], j0, J), rows[0], rows


def cv_select_ramp(y, train, val, j0=3, wavelet="sym4", n_iter=30, flat_tol=1.015):
    n = len(y)
    J = int(np.log2(n))
    mask_t = np.zeros(n); mask_t[train] = 1.0
    mask_v = np.zeros(n); mask_v[val] = 1.0
    rows = []
    for slope in np.linspace(0.6, 3.4, 15):
        lams = ramp_lams(slope, j0, J, power=1.5)
        pred_t = fit_masked_wavelet(y, mask_t, lams, j0, wavelet, n_iter)
        pred_v = fit_masked_wavelet(y, mask_v, lams, j0, wavelet, n_iter)
        score = np.mean((pred_t[val] - y[val]) ** 2) + np.mean((pred_v[train] - y[train]) ** 2)
        rows.append((float(score), float(slope)))
    rows = sorted(rows)
    min_score = rows[0][0]
    # High-frequency flat-minimum rule: choose the largest high-j slope whose
    # CV score is nearly indistinguishable from the minimum.
    cand = [r for r in rows if r[0] <= flat_tol * min_score]
    chosen = max(cand, key=lambda z: z[1])
    return ramp_lams(chosen[1], j0, J, power=1.5), chosen, rows


def oracle_ramp(y, f, j0=3, wavelet="sym4"):
    J = int(np.log2(len(y)))
    best = (np.inf, None)
    for slope in np.linspace(0.4, 4.0, 37):
        lams = ramp_lams(slope, j0, J, power=1.5)
        err = mse(shrink_full(y, lams, j0, wavelet), f)
        if err < best[0]:
            best = (err, slope)
    return best

# ------------------------------------------------------------
# Main simulation and plotting.
# ------------------------------------------------------------


def run_simulation(n=1024, snr=7.0, sigma=1.0, wavelet="sym4", j0=3, nrep=30, seed=2026, n_iter=30):
    J = int(np.log2(n))
    if 2**J != n:
        raise ValueError("n must be a power of two")
    if j0 != 3:
        print("Warning: this example was tuned for j0=3.")

    t, f = doppler_signal(n, snr, sigma)
    rng = np.random.default_rng(seed)
    records = []
    saved = None
    start = time.time()

    for r in range(nrep):
        y = f + rng.normal(0.0, sigma, size=n)

        # Levelwise SURE benchmark.
        l_sure = level_sure_lams(y, j0, wavelet, sigma)
        f_sure = shrink_full(y, l_sure, j0, wavelet)

        # Nason-type even/odd split with fixed global threshold.
        tr_n, va_n = max_or_wmax_split(y, j0, wavelet, kind="nason", seed=r)
        l_n, ch_n, rows_n = cv_select_fixed(y, tr_n, va_n, j0, wavelet, n_iter)
        f_n = shrink_full(y, l_n, j0, wavelet)

        # True MaxTwin on base location geometry, still fixed global threshold.
        tr_m, va_m = max_or_wmax_split(y, j0, wavelet, kind="max", seed=r)
        l_m, ch_m, rows_m = cv_select_fixed(y, tr_m, va_m, j0, wavelet, n_iter)
        f_m = shrink_full(y, l_m, j0, wavelet)

        # WMaxTwin split and high-frequency ramp thresholds.
        tr_w, va_w = max_or_wmax_split(y, j0, wavelet, kind="wmax", seed=r)
        l_w, ch_w, rows_w = cv_select_ramp(y, tr_w, va_w, j0, wavelet, n_iter)
        f_w = shrink_full(y, l_w, j0, wavelet)

        err_oracle, slope_oracle = oracle_ramp(y, f, j0, wavelet)

        records.append({
            "rep": r,
            "Noisy": mse(y, f),
            "LevelSure": mse(f_sure, f),
            "NasonEvenOddCV": mse(f_n, f),
            "MaxTwinFixedCV": mse(f_m, f),
            "WMaxTwinRampCV": mse(f_w, f),
            "OracleRamp": err_oracle,
            "selected_wmax_slope": ch_w[1],
            "oracle_slope": slope_oracle,
        })

        if r == 0:
            saved = {
                "t": t, "f": f, "y": y,
                "f_sure": f_sure, "f_nason": f_n, "f_maxtwin": f_m, "f_wmax": f_w,
                "train_wmax": tr_w, "val_wmax": va_w,
                "l_wmax": l_w, "l_sure": l_sure,
                "rows_wmax": rows_w,
                "j0": j0, "J": J,
                "wavelet": wavelet,
            }
        print(f"rep {r+1:3d}/{nrep} finished in {time.time()-start:6.2f}s", flush=True)

    return pd.DataFrame(records), saved


def save_outputs(df, saved, outprefix="/mnt/data/maxtwin_dl_doppler"):
    # CSV table.
    df.to_csv(outprefix + "_raw.csv", index=False)
    methods = ["Noisy", "LevelSure", "NasonEvenOddCV", "MaxTwinFixedCV", "WMaxTwinRampCV", "OracleRamp"]
    summ = []
    for m in methods:
        summ.append({
            "Method": m,
            "AMSE": df[m].mean(),
            "SD": df[m].std(ddof=1),
            "SE": df[m].std(ddof=1) / np.sqrt(len(df)),
        })
    tab = pd.DataFrame(summ)
    tab.to_csv(outprefix + "_amse.csv", index=False)

    t = saved["t"]
    # One-run reconstructions.
    plt.figure(figsize=(10, 5.6))
    plt.plot(t, saved["y"], linewidth=0.6, alpha=0.45, label="Noisy")
    plt.plot(t, saved["f"], linewidth=2.0, label="Truth")
    plt.plot(t, saved["f_nason"], linewidth=1.2, label="Nason even/odd CV")
    plt.plot(t, saved["f_wmax"], linewidth=1.6, label="WMaxTwin ramp CV")
    plt.xlabel("t")
    plt.ylabel("signal")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(outprefix + "_one_run.png", dpi=220)
    plt.close()

    # Split figure.
    idx = np.arange(len(t))
    tr = saved["train_wmax"]
    va = saved["val_wmax"]
    plt.figure(figsize=(10, 2.8))
    plt.scatter(t[tr], np.zeros_like(tr), s=8, label="training")
    plt.scatter(t[va], np.ones_like(va), s=8, label="validation")
    plt.yticks([0, 1], ["T", "R"])
    plt.xlabel("t")
    plt.ylim(-0.4, 1.4)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(outprefix + "_split.png", dpi=220)
    plt.close()

    # Thresholds.
    j0, J = saved["j0"], saved["J"]
    js = np.arange(j0, J)
    lam_w = np.array([saved["l_wmax"][int(j)] for j in js])
    lam_s = np.array([saved["l_sure"][int(j)] for j in js])
    plt.figure(figsize=(7, 4.5))
    plt.plot(js, lam_w, marker="o", label="WMaxTwin selected ramp")
    plt.plot(js, lam_s, marker="s", label="LevelSure")
    plt.xlabel("resolution level j")
    plt.ylabel("threshold")
    plt.xticks(js)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(outprefix + "_thresholds.png", dpi=220)
    plt.close()

    # CV curve for first replication.
    rows = np.asarray(saved["rows_wmax"])
    plt.figure(figsize=(7, 4.5))
    plt.plot(rows[:, 1], rows[:, 0], marker="o")
    plt.xlabel("high-frequency ramp slope")
    plt.ylabel("symmetric MaxTwin CV score")
    plt.tight_layout()
    plt.savefig(outprefix + "_cv_curve.png", dpi=220)
    plt.close()

    # AMSE bar.
    plt.figure(figsize=(9, 4.8))
    plt.bar(tab["Method"], tab["AMSE"], yerr=tab["SE"], capsize=4)
    plt.ylabel("AMSE")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(outprefix + "_amse_bar.png", dpi=220)
    plt.close()
    return tab


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=1024)
    parser.add_argument("--snr", type=float, default=7.0)
    parser.add_argument("--sigma", type=float, default=1.0)
    parser.add_argument("--wavelet", type=str, default="sym4", choices=list(FILTERS.keys()))
    parser.add_argument("--j0", type=int, default=3)
    parser.add_argument("--nrep", type=int, default=30)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--n_iter", type=int, default=30)
    parser.add_argument("--outprefix", type=str, default="/mnt/data/maxtwin_dl_doppler")
    args = parser.parse_args()

    df, saved = run_simulation(
        n=args.n, snr=args.snr, sigma=args.sigma, wavelet=args.wavelet,
        j0=args.j0, nrep=args.nrep, seed=args.seed, n_iter=args.n_iter,
    )
    tab = save_outputs(df, saved, args.outprefix)
    print("\nAMSE summary")
    print(tab.to_string(index=False))


if __name__ == "__main__":
    main()
