# WMaxTwin Doppler Nason Cross-Validation Notebook

This package contains a self-contained, executed Jupyter notebook for Example II of the WMaxTwin paper:

**MaxTwin / WMaxTwin Nason-type wavelet cross-validation for the Doppler signal.**

The notebook reproduces the Python simulation for the Doppler experiment with:

- `n = 1024`
- `SNR = 7`
- `sigma = 1`
- Symmlet 4 (`sym4`) periodized orthogonal wavelet transform
- analysis levels `j = 3, ..., 9`
- 18 Monte Carlo replications

The notebook explains:

1. why Nason's even/odd split is grid-compatible,
2. why a generic MaxTwin/WMaxTwin split cannot be followed by an ordinary DWT of retained observations,
3. how masked wavelet regression solves the nonconforming-mask problem,
4. how location-only MaxTwin differs from WMaxTwin,
5. how the WMaxTwin feature geometry uses local wavelet activity,
6. why the WMaxTwin ramp method improves in this example.

The notebook writes all numerical and graphical outputs to `outputs/`.

## Files

- `WMaxTwin_Doppler_Nason_CV_Notebook.ipynb`: executed annotated notebook.
- `example4_maxtwin_dl_doppler_original.py`: original uploaded Python script.
- `example4_maxtwin_dl_doppler_original.tex`: original uploaded LaTeX section.
- `requirements.txt`: minimal Python requirements.
- `outputs/`: generated figures and CSV tables.

## Run

```bash
pip install -r requirements.txt
jupyter notebook WMaxTwin_Doppler_Nason_CV_Notebook.ipynb
```

Then run all cells.

The default run takes around 10 to 20 seconds on a typical laptop. Increase `NREP` for a larger simulation.
